clear all; close all; clc; 

%% Initialization

A    =
B    =
Q1   =
Qf   =
Q2   =
x0   = [1;1];
Nsim = 20;



%% PART (a)

N      =
P{N+1} =
   
% Solving Ricatti equation
for t=N+1:-1:2

   % Recursion step
    P{t-1} = 

end


Lmat=[];
M=eye(2);

% Gain
for t=1:1:N

    % Calculate the gain using P{t+1}
    L{t}= 
    
end


%% PART (b)
p11(N+1) = P{N+1}(1,1); 
p12(N+1) = P{N+1}(1,2);
p21(N+1) = P{N+1}(2,1);
p22(N+1) = P{N+1}(2,2);

for t=N+1:-1:2

    p11(t-1) = P{t-1}(1,1); 

    p12(t-1) = P{t-1}(1,2);

    p21(t-1) = P{t-1}(2,1);

    p22(t-1) = P{t-1}(2,2);
    
end

figure 

subplot(2,2,1)
plot(p11)
ylabel('p11')
xlabel('Iteration')

subplot(2,2,2)
plot(p12)
ylabel('p12')
xlabel('Iteration')

subplot(2,2,3)
plot(p21)
ylabel('p21')
xlabel('Iteration')

subplot(2,2,4)
plot(p22)
ylabel('p2')
xlabel('Iteration')

%% PART (c)

% Form the matrix Lmat
for t=1:1:N

    Lmat=[Lmat; -L{t}*M];    
    M= ;
end
   
% Find the control sequence based on Lmat
u_ricatti=Lmat*x0;

figure 
plot(u_ricatti)
ylabel('u_ricatti')
xlabel('k')

%% PART (d)

% Form variables
for t=1:1:N
    
    x{t} =     
    u{t} = 
    
end

x{N+1} = 
    

% Form the cost and the constraints
cost=0; 
constraints = [x{1}== ];
for t=1:1:N
    
    cost = 
    
    constraints = [constraints, x{t+1}== ];
    
end


% Add terminal cost
cost = 

% Solve the problem
optimize(constraints, cost);

% Extract the control sequence
u_qp=[];

for t=1:1:N

    u_qp=[u_qp; value(u{t})];

end

% Compare the control sequences
figure
subplot(2,1,1)
hold on
plot(u_qp,'linewidth',2)
ylabel('u_{qp}')
xlabel('k')

subplot(2,1,2)
hold on
plot(u_ricatti,'linewidth',2)
ylabel('u_{ricatti}')
xlabel('k')

 %% PART (e)

 % Simulate the system
 xsim{1}=x0;
 for t=1:1:N
     
     xsim{t+1}=A*xsim{t}+B*value(u{t});
 
 end
 
 % Validate that the first N components agree with the prediction equations
 for t=1:1:N
     
     diffx(:,t)=xsim{t}-value(x{t});
     
 end
 

figure
subplot(2,1,1)
hold on
plot(diffx(1,:),'linewidth',2)
ylabel('Difference x_1')
ylim([-5 5])
xlabel('k')

subplot(2,1,2)
hold on
plot(diffx(2,:),'linewidth',2)
ylim([-5 5])
ylabel('Difference x_2')
xlabel('k')

 %% PART (f)
 
 % Simulate perturbed system
 Ap        =
 Bp        = 
 xsim_p{1} = 
 
 
 for t=1:1:N
     
     xsim_p{t+1} = 
     
 end
 
figure
subplot(211);
hold on; 
stairs(cell2mat(xsim)','linewidth',2);
ylabel('Nominal system')
legend('x_1','x_2')

subplot(212);
hold on; 
ylabel('Perturbed system')
stairs(cell2mat(xsim_p)','linewidth',2);
 
%% PART (g)

clear x, u;

N = 

% Form the variables
for t=1:1:N+1
    
    x{t} = 
    u{t} = 
    
end

% Form the cost and the constraints
cost=0; 
constraints=[];

for t=1:1:N
    
    cost =     
    constraints = [constraints, x{t+1}== ];
    
end

% Add the terminal cost
Qf   = Qf;  % Change later to stationary  solution  of  Riccati  equation
cost = cost+x{N+1}'*Qf*x{N+1};

options=sdpsettings('solver', 'gurobi');

% Controller function returns the first control input u{1} of 
% the optimal control sequence given x{1}
controller = optimizer(constraints, cost, [], x{1}, u{1});

% Simulate the nominal system
xrhc{1}=x0;
for t=1:1:Nsim
    
    urhc{t}   = 
    xrhc{t+1} = 
    
end

% Simulate the perturbed system
xrhc_p{1}=x0;
for t=1:1:Nsim
    
    urhc_p{t}   = 
    xrhc_p{t+1} = 
    
end

figure
subplot(211);
hold on; 
stairs(cell2mat(xrhc_p)','linewidth',2);
ylabel('Nominal system')
legend('x_1','x_2')

subplot(212);
hold on; 
ylabel('Perturbed system')
stairs(cell2mat(xrhc_p)','linewidth',2);
